package com.vet.veterinarian;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VeterinarianApplication {

	public static void main(String[] args) {
		SpringApplication.run(VeterinarianApplication.class, args);
	}

}
